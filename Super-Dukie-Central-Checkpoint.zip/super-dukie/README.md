# Super Dukie — central production record
Read START-HERE.md first. This repository is the project authority once its migration is activated.
Current deployment: PREPARED, NOT ON GITHUB. Migration is incomplete; missing artwork is explicitly recorded.
Shannon authorized this coordination system on 2026-10-13. This does not authorize artwork generation.
